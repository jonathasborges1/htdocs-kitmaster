A Pen created at CodePen.io. You can find this one at https://codepen.io/ahsanrathore/pen/MwppEB.

 Page Progress Bar with Navigation Timing API which provides data that can be used to measure the performance of a website. The PerformanceTiming interface represents timing-related performance information for the given page.